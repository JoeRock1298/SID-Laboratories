Readme - Hello MicroC/OS-II Hello Software Example

Hello_uosii is a simple hello world program running MicroC/OS-II.  The
purpose of the design is to be a very simple application that just
demonstrates MicroC/OS-II running on NIOS II.  The design doesn't account
for issues such as checking system call return codes. etc.

