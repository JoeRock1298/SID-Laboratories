/* confdefs.h */
#define PACKAGE_NAME "newlib"
#define PACKAGE_TARNAME "newlib"
#define PACKAGE_VERSION "2.2.0"
#define PACKAGE_STRING "newlib 2.2.0"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
