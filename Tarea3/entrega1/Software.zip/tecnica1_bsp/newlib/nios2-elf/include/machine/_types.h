/*
 *  $Id: //acds/rel/17.1std/ip/sopc/app/gnu/src/newlib-2.2/newlib/libc/include/machine/_types.h#1 $
 */

#ifndef _MACHINE__TYPES_H
#define _MACHINE__TYPES_H
#include <machine/_default_types.h>
#endif
