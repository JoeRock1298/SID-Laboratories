/* confdefs.h */
#define PACKAGE_NAME "newlib"
#define PACKAGE_TARNAME "newlib"
#define PACKAGE_VERSION "2.2.0"
#define PACKAGE_STRING "newlib 2.2.0"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
#define _WANT_IO_LONG_LONG 1
#define _MB_LEN_MAX 1
#define _NEWLIB_VERSION "2.2.0"
#define _ATEXIT_DYNAMIC_ALLOC 1
#define _FVWRITE_IN_STREAMIO 1
#define _FSEEK_OPTIMIZATION 1
#define _WIDE_ORIENT 1
#define _UNBUF_STREAM_OPT 1
#define _HAVE_CC_INHIBIT_LOOP_TO_LIBCALL 1
#define _HAVE_LONG_DOUBLE 1
#define _LDBL_EQ_DBL 1
