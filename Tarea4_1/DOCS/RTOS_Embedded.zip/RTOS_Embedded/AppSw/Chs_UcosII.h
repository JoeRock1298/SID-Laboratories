/*
 * Chs_UcosII.h
 *
 *  Created on: 10 de dic. de 2020
 *      Author: mpeiro
 */

#ifndef APPSW_CHS_UCOSII_H_
#define APPSW_CHS_UCOSII_H_

#include <stdio.h>
#include "includes.h"
#include "../BaseSw/inc/app_config.h"



#endif /* APPSW_CHS_UCOSII_H_ */
